package day1;
import java.util.*;
public class Demo {

	public static void main(String[] args) {
		int a,b,c;
		Scanner s=new Scanner(System.in);
		System.out.println("enter the values of a and b");
		a=s.nextInt();
		b=s.nextInt();
		c=a+b;
		System.out.println("Addition of a="+a+" and b="+b+" is :"+c);
		System.out.println("hello");
	}
}
























