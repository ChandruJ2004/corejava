package day1;

import java.util.Scanner;

public class multi {

	public static void main(String[] args) {
		int a,b,c;
		Scanner s=new Scanner(System.in);
		System.out.println("enter the values of a and b:");
		a=s.nextInt();
		b=s.nextInt();
		c=a*b;
		System.out.println("a * b ="+c);

	}

}
