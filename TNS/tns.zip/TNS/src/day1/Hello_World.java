package day1;

public class Hello_World {

	public static void main(String[] args) {
		System.out.println("Hello World");

	}

}
