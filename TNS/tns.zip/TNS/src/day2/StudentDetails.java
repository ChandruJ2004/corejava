package day2;

public class StudentDetails {

	public static void main(String[] args) {
		private 
	}

}
