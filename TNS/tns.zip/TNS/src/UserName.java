import java.util.Scanner;

public class UserName {

	public static void main(String[] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("enter your name");
		String n=input.nextLine();
		System.out.println("hello "+n);
	}

}
